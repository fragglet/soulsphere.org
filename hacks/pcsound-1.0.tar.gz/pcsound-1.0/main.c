// Emacs style mode select -*- C++ -*-
//-----------------------------------------------------------------------
//
// Copyright(C) 2001 Simon Howard
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of version 2.1 of the GNU Lesser 
// General Public License as published by the Free Software Foundation.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
//
//--------------------------------------------------------------------------
//
// Test code
//
//--------------------------------------------------------------------------

#include <stdio.h>
#include <time.h>

#include "pcsound.h"

int main() 
{
	int i;

	// init library
	
	Speaker_Init();

	// play some tunes

	puts("playing a short tune");
	
	for(i=1000; i<=1800; i+= 200) 
		Speaker_Sound(i, 20);

	Speaker_Off();

	puts("press a key");

	getch();

	// play a tone in the background
	
	puts("playing a tone, press a key to stop");
	
	Speaker_Output(3000);

	while(!kbhit()) {
		i = (clock() * 2 / CLOCKS_PER_SEC) % 4;
		printf("%c\b", "|/-\\"[i]);
	}

	printf("\n");

	Speaker_Off();
}

