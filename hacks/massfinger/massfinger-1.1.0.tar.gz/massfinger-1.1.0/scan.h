// Emacs style mode select -*- C++ -*-
//------------------------------------------------------------------------
//
// Copyright(c) 2001, 2002 Simon Howard
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//--------------------------------------------------------------------------
//
// Multi process forking code for faster scanning
//
//--------------------------------------------------------------------------

#ifndef __SCAN_H__
#define __SCAN_H__

#include "types.h"

//==========================================================================
//
// Stuff used by child scanning processes
//
//==========================================================================

void scan_add_user(int machine, char *user);

void scan_set_status(int machine, machinestatus_t status);

//==========================================================================
//
// Parent code interface to scanner
//
//==========================================================================

// returns true if still scanning

int scan_waiting();

// read new data from scanning subprocesses

void scan_update();

//==========================================================================
//
// Main Scanning code
// 
//==========================================================================

void scan_machines();

#endif
