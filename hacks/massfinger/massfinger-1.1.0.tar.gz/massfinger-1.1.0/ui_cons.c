// Emacs style mode select -*- C++ -*-
//------------------------------------------------------------------------
//
// Copyright(c) 2001, 2002 Simon Howard
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//--------------------------------------------------------------------------
//
// Console Mode status display
//
//--------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include "parse.h"
#include "ui.h"

void ui_init()
{
}

void ui_add_user(machine_t *machine, user_t *user)
{
}

// print machine name and type

static void print_machine(machine_t *machine) 
{
        int i;

        printf("%s", machine->hostname);
        
        for(i=0; i<18-strlen(machine->hostname); ++i)
                putc(' ', stdout);
        
        printf("%s   ", 
               machine->type == MACHINE_UNIX ?  "[unix] " : 
               machine->type == MACHINE_LINUX ? "[linux]" :
               machine->type == MACHINE_WIN ?   "[win]  " : "       ");
}

void ui_run()
{
        int c, m, u;
        
        printf("Scanning....\n");
        
        // read all users

        while(scan_waiting()) {
                scan_update();
                usleep(100);          // dont thrash the cpu too much
        }


        // print all users on all machines on all clusters
        
        for(c=0; c<num_clusters; c++) {
                
                
                printf("\n**** %s ****\n\n", clusters[c]->name);
                
                for(m=0; m<clusters[c]->num_machines; m++) {
                        machine_t *machine = clusters[c]->machines[m];

                        if(!machine->num_users) {
                                print_machine(machine);
                                printf("--- %s ---\n",
                                       machine->status == STATUS_UP ? "free" :
                                       machine->status == STATUS_UNKNOWN ? "up" :
                                       machine->status == STATUS_DOWN ? "down" : "wtf");
                        }

                        for(u=0; u<machine->num_users; u++) {
                                print_machine(machine);
                                printf("%s\n", machine->users[u]->name);
                        }
                }
        }
}

void ui_set_status(machine_t *machine, machinestatus_t status)
{
}

void *ui_new_interface_data(machine_t *machine)
{
	return NULL;
}
