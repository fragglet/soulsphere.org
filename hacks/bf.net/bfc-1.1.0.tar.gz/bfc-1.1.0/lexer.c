//
// Copyright(c) 2001 Simon Howard
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of version 2 of the GNU General Public License
// as published by the Free Software Foundation.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//------------------------------------------------------------------------------
//
// Lexer
//
//------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>

#include "lexer.h"

static FILE *parsefile = NULL;

token_t Lexer_NextToken()
{
	for (; parsefile && !feof(parsefile); ) {
		unsigned char c = fgetc(parsefile);

		switch (c) {
		case '[': return TOKEN_LOOPSTART;
		case ']': return TOKEN_LOOPEND;
		case ',': return TOKEN_READ;
		case '.': return TOKEN_WRITE;
		case '<': return TOKEN_PREV;
		case '>': return TOKEN_NEXT;
		case '-': return TOKEN_MINUS;
		case '+': return TOKEN_PLUS;
		default: break;
		}
	}

	return TOKEN_NONE;
}

void Lexer_ParseFile(FILE *f)
{
	parsefile = f;
}
