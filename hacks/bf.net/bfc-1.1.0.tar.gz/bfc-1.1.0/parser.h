//
// Copyright(c) 2001 Simon Howard
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of version 2 of the GNU General Public License
// as published by the Free Software Foundation.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//--------------------------------------------------------------------------

#ifndef __PARSER_H__
#define __PARSER_H__

#include <stdio.h>

typedef struct treenode_s treenode_t;
typedef struct treenodelist_s treenodelist_t;
typedef struct loopnode_s loopnode_t;

struct treenode_s {
	void (*print)(treenode_t *node, FILE *fstream);
	union {
		void *v;
		int i;
	} data;
};

struct treenodelist_s {
	int num_nodes;
	treenode_t **nodes;
};

struct loopnode_s {
	treenode_t *list;
	int loop_num;
};

treenode_t *Parser_ParseFile(FILE *fstream);

#endif 
