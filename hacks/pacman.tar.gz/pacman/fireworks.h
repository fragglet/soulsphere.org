#ifndef FIREWORKS_H
#define FIREWORKS_H

#include "level.h"

void fireworks_init(Level *lev);
void fireworks_run();
void fireworks_draw();

#endif
