#ifndef OBJECTS_H
#define OBJECTS_H

#include "level.h"

extern LevelObject *ghost_new(Level *level, int x, int y);
extern LevelObject *player_new(Level *level, int x, int y);
extern void player_set_movedir(LevelObject *obj, int angle);
#endif
