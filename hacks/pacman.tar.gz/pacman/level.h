#ifndef __LEVEL_H__
#define __LEVEL_H__

typedef struct _Level Level;
typedef struct _LevelObject LevelObject;

typedef enum {
	SQUARE_EMPTY,
	SQUARE_DOT,		// empty with dot
	SQUARE_PILL,		// empty with powerpill
	SQUARE_WALL,
} LevelSquare;

typedef enum {
	OBJECT_PLAYER,
	OBJECT_GHOST,
} LevelObjectType;

#define NUM_MOUNTAINS 20

struct _LevelObject {
	LevelObjectType type;
	
	int x, y;
	int target_x, target_y;
	int angle;
	void *extradata;

	int countdown;
	int speed;

	void (*draw)(Level *level, LevelObject *obj);
	void (*move)(Level *level, LevelObject *obj);
	void (*destructor)(LevelObject *obj);

	LevelObject *next;
};

struct _Level {
	int w, h;

	int time;

	float mountains[NUM_MOUNTAINS];
	
	int dots_remaining;
	int gameover;
	int draw_fireworks;

	int tourmode;
	
	LevelSquare *data;
	LevelObject *objects;

	LevelObject *player;

	struct {
		int enabled;
		float x;
		float y;
		int angle;
	} chasecam;
};

Level *level_new();
void level_draw(Level *level);
void level_run(Level *level);
void level_destroy(Level *level);

#endif /* #ifndef __LEVEL_H__ */
