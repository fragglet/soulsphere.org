#ifndef __DRAW_H__
#define __DRAW_H__

static inline void glReloadMatrix()
{
	glPopMatrix();
	glPushMatrix();
}

void draw_disc(int sections);
void draw_ring(int sections);
void draw_ring_frill(int sections);
void draw_cylinder(int sections);
void draw_partial_sphere(int hsections, int vsections, int total_vsections);
void draw_hemisphere(int hsections, int vsections);
void draw_sphere(int hsections, int vsections);

#endif /* #ifndef __DRAW_H__ */
