#ifndef __AAWIN32_H_INCLUDED__
#define __AAWIN32_H_INCLUDED__

#include <windows.h>

#define KBD_BUFFERSIZE 128

struct win32driverdata
{
  HWND hWnd;
  int ConWidth, ConHeight;

  int writex, writey;   // write point in output buffer

  int use_kbd;  
  int kbd_buffer[KBD_BUFFERSIZE];
  int kbd_head, kbd_tail;

  int redrawflag;       // set to nonzero if we need to redraw the window
};

#endif
