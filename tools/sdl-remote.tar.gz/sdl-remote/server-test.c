#include <SDL.h>

int main(int argc, char *argv[])
{
    SDL_Init(SDL_INIT_VIDEO);

    SDL_Remote_StartServer();

    while (1)
    {
        SDL_Event ev;

        while (SDL_PollEvent(&ev))
        {
            printf("Event received of type %i\n", ev.type);
        }
        
        SDL_Delay(1000);
    }
}

