#include <stdlib.h>

#include <SDL.h>
#include <SDL_net.h>

#define PORT 4444

static TCPsocket sock;

static void Connect(char *host)
{
    IPaddress addr;

    SDLNet_ResolveHost(&addr, host, PORT);

    sock = SDLNet_TCP_Open(&addr);

    if (sock == NULL)
    {
        fprintf(stderr, "Error connecting to server: %s\n", SDLNet_GetError());
        exit(-1);
    }
}

static void InitScreen(void)
{
    // Create a window

    if (SDL_SetVideoMode(320, 200, 0, 0) == NULL)
    {
        fprintf(stderr, "Unable to set video mode: %s\n", SDL_GetError());
        exit(-1);
    }

    SDL_WM_GrabInput(SDL_GRAB_ON);
    SDL_ShowCursor(0);
}

static void EventLoop(void)
{
    SDL_Event event;
    
    while (SDL_WaitEvent(&event))
    {
        SDLNet_TCP_Send(sock, &event, sizeof(event));
    }
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("Usage: %s <host>\n", argv[0]);
        exit(-1);
    }

    SDL_Init(SDL_INIT_VIDEO);
    
    Connect(argv[1]);

    InitScreen();
    EventLoop();

    return 0;
}

