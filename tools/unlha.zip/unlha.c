
#include <string.h>
#include <time.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "unlha32.h"

static char buf[65536];

int main(int argc, char *argv[])
{
	char *cmdline;

	cmdline = GetCommandLine();
	cmdline += strlen(argv[0]) + 1;

	Unlha(NULL, cmdline, buf, sizeof(buf));

	puts(buf);

	return 0;
}

