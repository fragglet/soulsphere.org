// Emacs style mode select   -*- C++ -*-
//-----------------------------------------------------------------------------
//
// $Id: version.c,v 1.1.1.1 2000-07-29 13:20:41 fraggle Exp $
//
//-----------------------------------------------------------------------------

static const char rcsid[] = "$Id: version.c,v 1.1.1.1 2000-07-29 13:20:41 fraggle Exp $";

#include "version.h"

const char version_date[] = __DATE__;

//----------------------------------------------------------------------------
//
// $Log: version.c,v $
// Revision 1.1.1.1  2000-07-29 13:20:41  fraggle
// imported sources
//
// Revision 1.2  1998/05/03  22:59:31  killough
// beautification
//
// Revision 1.1  1998/02/02  13:21:58  killough
// version information files
//
//----------------------------------------------------------------------------
