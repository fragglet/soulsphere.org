// Emacs style mode select -*- C++ -*-
//-----------------------------------------------------------------------------
//

#ifndef __HU_FRAGS_H__
#define __HU_FRAGS_H__

void HU_FragsInit();

void HU_FragsDump();
void HU_FragsUpdate();
void HU_FragsDrawer();
void HU_FragsErase();

#endif
