// Emacs style mode select -*- C++ -*-
//----------------------------------------------------------------------------
//

#ifndef MN_MENUS_H
#define MN_MENUS_H

void MN_InitMenus();
void MN_ShowFrameRate();

#endif          /** MN_MENUS_H **/
