// Emacs style mode select -*- C++ -*-
//-----------------------------------------------------------------------------
//

#ifndef __OPERATOR_H__
#define __OPERATOR_H__

#include "t_parse.h"

extern operator_t operators[];
extern int num_operators;

#endif
