#ifndef __R_RIPPLE_H__
#define __R_RIPPLE_H__

char *R_DistortedFlat(int flatnum);
extern int r_swirl;

#endif
