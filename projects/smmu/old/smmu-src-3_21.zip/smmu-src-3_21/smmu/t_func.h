// Emacs style mode select -*- C++ -*-
//-----------------------------------------------------------------------------
//

#ifndef __FUNC_H__
#define __FUNC_H__

#include "t_parse.h"

void init_functions();

#endif
