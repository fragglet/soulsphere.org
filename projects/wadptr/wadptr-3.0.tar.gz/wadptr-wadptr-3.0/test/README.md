Test WADs for wadptr compression. Use the `run_tests.sh` script to
run tests. Included here are:

* The `6fiffy*` series, levels by George Fiffy (King REoL) who is
  notorious for his "extreme detail" levels that contain a large number
  of linedefs and sidedefs. `6fiffy6.wad` is a Hexen format level,
  which checks that we handle such WADs appropriately.
* Eternal Doom,  which is similarly notorious for having very large
  levels.
