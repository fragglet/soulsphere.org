wadptr is a tool for compressing Doom .wad files. It takes advantage of the
structure of the WAD format and some of the lumps stored inside it to merge
repeated data.

Building wadptr requires a toolchain with at least C99 and POSIX.1-2008
support, plus GNU make. Contemporary systems based on Linux, BSD,
Solaris/Illumos, Cygwin or mingw-w64 will do.

Apocrypha: ["You should have used WADPTR"](https://www.youtube.com/watch?v=EO849hbGP-c) - unhappily dshrunk fraggle
